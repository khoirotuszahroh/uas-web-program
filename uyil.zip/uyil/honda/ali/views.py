from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

def index(request):
  template = loader.get_template('index.html')
  return HttpResponse(template.render())
def about(request):
  template = loader.get_template('about.html')
  return HttpResponse(template.render())
def clients(request):
  template = loader.get_template('clients.html')
  return HttpResponse(template.render())
def contact(request):
  template = loader.get_template('contact.html')
  return HttpResponse(template.render())
def testmonial(request):
  template = loader.get_template('testmonial.html')
  return HttpResponse(template.render())


# def comen(request):
#   template = loader.get_template('comen.html')
#   return HttpResponse(template.render())

# def work(request):
#   template = loader.get_template('work.html')
#   return HttpResponse(template.render())
# def contact(request):
#   template = loader.get_template('contact.html')
#   return HttpResponse(template.render())



# from django.shortcuts import render
# from django.http import HttpResponseForbidden
# from .forms import BeritaForm  

# def index1(request):
#     if request.method == 'POST':
#         form = BeritaForm(request.POST)
#   …